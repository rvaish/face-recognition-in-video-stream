#include "stdafx.h"

#include "cv.h"
#include "highgui.h"
#include "cvaux.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <time.h>
#include <ctype.h>
#include <atlstr.h>
#include <atlimage.h>

#include <time.h>
#include<atltime.h>



static CvMemStorage* storage = 0;
static CvHaarClassifierCascade* cascade = 0;
void detect_and_draw( IplImage* image ,int counter);
const char* cascade_name ="haarcascade_frontalface_alt.xml";




//// Global variables
IplImage ** faceImgArr        = 0; // array of face images
CvMat    *  personNumTruthMat = 0; // array of person numbers
int nTrainFaces               = 0; // the number of training images
int nEigens                   = 0; // the number of eigenvalues
IplImage * pAvgTrainImg       = 0; // the average image
IplImage ** eigenVectArr      = 0; // eigenvectors
CvMat * eigenValMat           = 0; // eigenvalues
CvMat * projectedTrainFaceMat = 0; // projected training faces
int fno=0;


//// Function prototypes
void learn();
int recognize(void);
void doPCA();
void storeTrainingData();
int  loadTrainingData(CvMat ** pTrainPersonNumMat);
int  findNearestNeighbor(float * projectedTestFace);
int  loadFaceImgArray(char * filename);
void printUsage();
int recognizemain();



int main( int argc, char** argv )
{
//
	learn();
	





CvCapture* capture = 0;
IplImage *frame, *frame_copy = 0;
int optlen = strlen("--cascade=");
const char* input_name;
if( argc > 1 && strncmp( argv[1], "--cascade=", optlen ) == 0 )
{
cascade_name = argv[1] + optlen;
//printf("%s",cascade_name);
 input_name = argc > 2 ? argv[2] : 0;
 }
 else
 {
 fprintf( stderr,"Usage: facedetect --cascade=\"<cascade_path>\" [filename|camera_index]\n" );
 return -1;
 }
 cascade = (CvHaarClassifierCascade*)cvLoad( cascade_name,0,0,0);
 if( !cascade )
 {
 fprintf( stderr, "ERROR: Could not load classifier cascade\n" );
 return -1;
 }
 storage = cvCreateMemStorage(0);
 if( !input_name || (isdigit(input_name[0]) && input_name[1] == '\0') )
 capture = cvCaptureFromCAM( !input_name ? 0 : input_name[0] - '0' );
 else
 capture = cvCaptureFromAVI( input_name ); 
 cvNamedWindow( "FRVS Result Window",1);
 if( capture )
 {
 for(;;)
 {
if( !cvGrabFrame( capture ))
break;
frame = cvRetrieveFrame( capture );
if( !frame )
break;
if( !frame_copy )
frame_copy = cvCreateImage( cvSize(frame->width,frame->height),  IPL_DEPTH_8U, frame->nChannels );
if( frame->origin == IPL_ORIGIN_TL )
 cvCopy( frame, frame_copy, 0 );
else
cvFlip( frame, frame_copy, 0 );

detect_and_draw( frame_copy,1);

char key=cvWaitKey(10);
    if(key==27) break;

    switch(key){
      case 'h':
		 
		  detect_and_draw( frame_copy,1 );
		  cvWaitKey(0);
	}
if( cvWaitKey( 10 ) >= 0 )
break;
}

cvReleaseImage( &frame_copy );
cvReleaseCapture( &capture );
}

else
{
const char* filename = input_name ? input_name : (char*)"a.jpg";
IplImage* image = cvLoadImage( filename, 1 );
if( image )
{
detect_and_draw( image,0 );
cvWaitKey(0);
cvReleaseImage( &image );
}
else
{
FILE* f = fopen( filename, "rt" );
if( f )
{
char buf[1000+1];
while( fgets( buf, 1000, f ) )
{
int len = (int)strlen(buf);
while( len > 0 && isspace(buf[len-1]) )
len--;
buf[len] = '\0';
image = cvLoadImage( buf, 1 );
if( image )
 {
 detect_and_draw( image ,0);
 cvWaitKey(0);
 cvReleaseImage( &image );
 }
 }
fclose(f);
 }
 }
}
    
cvDestroyWindow("FRVS Result Window");

int l=recognizemain();
if(l==1) 
		printf("nearest = rajan %d\n", l);
if(l==2) 
		printf("nearest = vivek %d\n", l);
Sleep(10000);

return 0;
}


void detect_and_draw( IplImage* img ,int counter)
{
    int scale = 1;
IplImage* temp = cvCreateImage( cvSize(img->width/scale,img->height/scale),8,3);
CvPoint pt1, pt2;
 int i;
cvClearMemStorage( storage );
 if( cascade )
  {
  
	    	LARGE_INTEGER liStart;
LARGE_INTEGER liStop;
LARGE_INTEGER liFreq;

::QueryPerformanceFrequency(&liFreq);

// Start time measurement
::QueryPerformanceCounter(&liStart); // Do your processing
// Stop time measurement
CvSeq* faces = cvHaarDetectObjects( img, cascade, storage,1.1,2, CV_HAAR_DO_CANNY_PRUNING,cvSize(100, 100) );
/*::QueryPerformanceCounter(&liStop);

LONGLONG a = liStop.QuadPart - liStart.QuadPart;
double elapsedTime = (double)a*1000.0/(double)liFreq.QuadPart;
printf("%f",elapsedTime);
cvWaitKey(0);
*/	  
IplImage* faceimg;
for( i = 0; i < (faces ? faces->total : 0); i++ )
  {

//cvSetImageROI(img,*r);
//cvResize(img,faceimg);
//printf("x1=%d,y1=%d,x2=%d,y2=%d\n",pt1.x,pt1.y,pt2.x,pt2.y);
//cvShowImage("faces",faceimg);
//cvWaitKey(0);
//cvReleaseImage(&faceimg);
//cvDestroyWindow("faces");


//NNNNN

///FOr resizing 
//CvRect * pFaceRect = (CvRect*)cvGetSeqElem(pRectSeq, 0); 
//cvSetImageROI(pImg, *pFaceRect); 
//IplImage * pFaceImg = 
//  cvCreateImage( STD_SIZE, IPL_DEPTH_8U, 1 ); 
//cvResize(pImg, pFaceImg, CV_INTER_AREA );

////

IplImage *img1= cvCreateImage( cvSize(img->width,img->height),  IPL_DEPTH_8U, img->nChannels );

cvNamedWindow( "faces",1);
 CvRect *r = (CvRect*)cvGetSeqElem( faces, i );
faceimg=cvCreateImage(cvSize(100,100),8,3);



pt1.x = r->x*scale;
pt2.x = (r->x+r->width)*scale;
pt1.y = r->y*scale;

pt2.y = (r->y+r->height)*scale;
cvCopy( img, img1, 0 );
cvSetImageROI(img1,*r);



cvResize(img1,faceimg,CV_INTER_AREA);
printf("x1=%d,y1=%d,x2=%d,y2=%d\n",pt1.x,pt1.y,pt2.x,pt2.y);
//
//cvShowImage("faces",faceimg);
//cvReleaseImage(&faceimg);
//cvDestroyWindow("faces");

//NNNNNNNN



printf("\n%d",counter);


//CImage


CvFont myFont;//Declare font

//Initialise font
cvInitFont(&myFont,CV_FONT_HERSHEY_COMPLEX_SMALL ,0.75f,0.75f,0,1,8); 



if(counter==1){
	 fno=fno+1;
//char s[6];
//itoa(fno,s,10);
//
//strcat(s,".jpg\0");
//printf("%s",s);
//cvSaveImage(s,faceimg);	
cvSaveImage("1.jpg",faceimg);
	

int l=recognize();int nearest=0;
if(l==1) 
{
cvRectangle( img, pt1, pt2, CV_RGB(0,0,0), 3, 8, 0 );

	cvPutText(img,"Rajan",pt1,&myFont,cvScalar(255));
	
	printf("nearest = rajan %d\n",l);

}
if(l==2) 
{cvRectangle( img, pt1, pt2, CV_RGB(0,0,0), 3, 8, 0 );

	cvPutText(img,"vivek",pt1,&myFont,cvScalar(255));
	
		printf("nearest = vivek %d\n", l);
}
		if(l==3) 
		{
			cvRectangle( img, pt1, pt2, CV_RGB(0,0,0), 3, 8, 0 );

	cvPutText(img,"Vivek",pt1,&myFont,cvScalar(255));
	

			printf("nearest = Vivek %d\n ",l);

		}
	
	//cvWaitKey(0);
}
}
}
cvShowImage( "FRVS Result Window", img );
cvReleaseImage( &temp );
}








int recognizemain()
{
	// validate that an input was specified
	learn();
	
		LARGE_INTEGER liStart;
LARGE_INTEGER liStop;
LARGE_INTEGER liFreq;

::QueryPerformanceFrequency(&liFreq);

// Start time measurement
::QueryPerformanceCounter(&liStart); // Do your processing
// Stop time measurement
int l=recognize();
::QueryPerformanceCounter(&liStop);

LONGLONG a = liStop.QuadPart - liStart.QuadPart;
double elapsedTime = (double)a*1000.0/(double)liFreq.QuadPart;
		/*CTime tStart = CTime::GetCurrentTime();
		
		
		CTime tEnd = CTime::GetCurrentTime();

CTimeSpan spanOfExc = tEnd - tStart;
//CString s = spanOfExc.Format( "Total days: %D, hours: %H, mins: %M, secs: %S" );
LONGLONG a=spanOfExc.GetTotalSeconds();*/
printf("%f",elapsedTime);
	return l;
}


//////////////////////////////////
// learn()
//
void learn()
{
	int i, offset;

	// load training data
	nTrainFaces = loadFaceImgArray("train.txt");
	if( nTrainFaces < 2 )
	{
		fprintf(stderr,
		        "Need 2 or more training faces\n"
		        "Input file contains only %d\n", nTrainFaces);
		return;
	}

	// do PCA on the training faces
	doPCA();

	// project the training images onto the PCA subspace
	projectedTrainFaceMat = cvCreateMat( nTrainFaces, nEigens, CV_32FC1 );
	offset = projectedTrainFaceMat->step / sizeof(float);
	for(i=0; i<nTrainFaces; i++)
	{
		//int offset = i * nEigens;
		cvEigenDecomposite(
			faceImgArr[i],
			nEigens,
			eigenVectArr,
			0, 0,
			pAvgTrainImg,
			//projectedTrainFaceMat->data.fl + i*nEigens);
			projectedTrainFaceMat->data.fl + i*offset);
	}

	// store the recognition data as an xml file
	storeTrainingData();
}



// recognize

int recognize(void)
{
	int i, testFacesnumber  = 0;         // the number of test images
	CvMat * trainPersonNumMat = 0;  // the person numbers during training
	float * projectedTestFace = 0;

	// load test images and ground truth for person number
	testFacesnumber = loadFaceImgArray("test.txt");
	printf("%d test faces loaded\n", testFacesnumber);

	// load the saved training data
	if( !loadTrainingData( &trainPersonNumMat ) ) return -1;

	// project the test images onto the PCA subspace
	projectedTestFace = (float *)cvAlloc( nEigens*sizeof(float) );
	int l=0;
	for(i=0; i<testFacesnumber; i++)
	{
		int iNearest, nearest, truth;

		// project the test image onto the PCA subspace
		cvEigenDecomposite(
			faceImgArr[i],
			nEigens,
			eigenVectArr,
			0, 0,
			pAvgTrainImg,
			projectedTestFace);

		iNearest = findNearestNeighbor(projectedTestFace);
		truth    = personNumTruthMat->data.i[i];
		nearest  = trainPersonNumMat->data.i[iNearest];
		l=nearest;
		printf("nearest = %d, Truth = %d\n", nearest, truth);
		
	}
	return l;
	remove("1.jpg");

}


//////////////////////////////////
// loadTrainingData()
//
int loadTrainingData(CvMat ** pTrainPersonNumMat)
{
	CvFileStorage * fileStorage;
	int i;

	// create a file-storage interface
	fileStorage = cvOpenFileStorage( "facedata.xml", 0, CV_STORAGE_READ );
	if( !fileStorage )
	{
		fprintf(stderr, "Can't open facedata.xml\n");
		return 0;
	}

	nEigens = cvReadIntByName(fileStorage, 0, "nEigens", 0);
	nTrainFaces = cvReadIntByName(fileStorage, 0, "nTrainFaces", 0);
	*pTrainPersonNumMat = (CvMat *)cvReadByName(fileStorage, 0, "trainPersonNumMat", 0);
	eigenValMat  = (CvMat *)cvReadByName(fileStorage, 0, "eigenValMat", 0);
	projectedTrainFaceMat = (CvMat *)cvReadByName(fileStorage, 0, "projectedTrainFaceMat", 0);
	pAvgTrainImg = (IplImage *)cvReadByName(fileStorage, 0, "avgTrainImg", 0);
	eigenVectArr = (IplImage **)cvAlloc(nTrainFaces*sizeof(IplImage *));
	for(i=0; i<nEigens; i++)
	{
		char varname[200];
		sprintf( varname, "eigenVect_%d", i );
		eigenVectArr[i] = (IplImage *)cvReadByName(fileStorage, 0, varname, 0);
	}

	
	cvReleaseFileStorage( &fileStorage );

	return 1;
}


//////////////////////////////////
// storeTrainingData()
//
void storeTrainingData()
{
	CvFileStorage * fileStorage;
	int i;

	// create a file-storage interface
	fileStorage = cvOpenFileStorage( "facedata.xml", 0, CV_STORAGE_WRITE );

	// store all the data
	cvWriteInt( fileStorage, "nEigens", nEigens );
	cvWriteInt( fileStorage, "nTrainFaces", nTrainFaces );
	cvWrite(fileStorage, "trainPersonNumMat", personNumTruthMat, cvAttrList(0,0));
	cvWrite(fileStorage, "eigenValMat", eigenValMat, cvAttrList(0,0));
	cvWrite(fileStorage, "projectedTrainFaceMat", projectedTrainFaceMat, cvAttrList(0,0));
	cvWrite(fileStorage, "avgTrainImg", pAvgTrainImg, cvAttrList(0,0));
	for(i=0; i<nEigens; i++)
	{
		char varname[200];
		sprintf( varname, "eigenVect_%d", i );
		cvWrite(fileStorage, varname, eigenVectArr[i], cvAttrList(0,0));
	}

	// release the file-storage interface
	cvReleaseFileStorage( &fileStorage );
}



// findNearestNeighbor()

int findNearestNeighbor(float * projectedTestFace)
{
	double leastDistSquare = DBL_MAX;
	int i, iTrain, iNearest = 0;

	for(iTrain=0; iTrain<nTrainFaces; iTrain++)
	{
		double distSq=0;

		for(i=0; i<nEigens; i++)
		{
			float d_i =
				projectedTestFace[i] -
				projectedTrainFaceMat->data.fl[iTrain*nEigens + i];
			//distSq += d_i*d_i / eigenValMat->data.fl[i];  // Mahalanobis
			distSq += d_i*d_i; // Euclidean
		}

		if(distSq < leastDistSquare)
		{
			leastDistSquare = distSq;
			iNearest = iTrain;
		}
	}

	return iNearest;
}


//////////////////////////////////
// doPCA()
//
void doPCA()
{
	int i;
	CvTermCriteria calcLimit;
	CvSize faceImgSize;

	// set the number of eigenvalues to use
	nEigens = nTrainFaces-1;

	// allocate the eigenvector images
	faceImgSize.width  = faceImgArr[0]->width;
	faceImgSize.height = faceImgArr[0]->height;
	eigenVectArr = (IplImage**)cvAlloc(sizeof(IplImage*) * nEigens);
	for(i=0; i<nEigens; i++)
		eigenVectArr[i] = cvCreateImage(faceImgSize, IPL_DEPTH_32F, 1);

	// allocate the eigenvalue array
	eigenValMat = cvCreateMat( 1, nEigens, CV_32FC1 );

	// allocate the averaged image
	pAvgTrainImg = cvCreateImage(faceImgSize, IPL_DEPTH_32F, 1);

	// set the PCA termination criterion
	calcLimit = cvTermCriteria( CV_TERMCRIT_ITER, nEigens, 1);

	// compute average image, eigenvalues, and eigenvectors
	cvCalcEigenObjects(
		nTrainFaces,
		(void*)faceImgArr,
		(void*)eigenVectArr,
		CV_EIGOBJ_NO_CALLBACK,
		0,
		0,
		&calcLimit,
		pAvgTrainImg,
		eigenValMat->data.fl);

	cvNormalize(eigenValMat, eigenValMat, 1, 0, CV_L1, 0);
}


//////////////////////////////////
// loadFaceImgArray()
//
int loadFaceImgArray(char * filename)
{
	FILE * imgListFile = 0;
	char imgFilename[512];
	int iFace, nFaces=0;


	// open the input file
	if( !(imgListFile = fopen(filename, "r")) )
	{
		fprintf(stderr, "Can\'t open file %s\n", filename);
		return 0;
	}

	// count the number of faces
	while( fgets(imgFilename, 512, imgListFile) ) ++nFaces;
	rewind(imgListFile);

	// allocate the face-image array and person number matrix
	faceImgArr        = (IplImage **)cvAlloc( nFaces*sizeof(IplImage *) );
	personNumTruthMat = cvCreateMat( 1, nFaces, CV_32SC1 );

	// store the face images in an array
	for(iFace=0; iFace<nFaces; iFace++)
	{
		// read person number and name of image file
		fscanf(imgListFile,
			"%d %s", personNumTruthMat->data.i+iFace, imgFilename);

		// load the face image
		faceImgArr[iFace] = cvLoadImage(imgFilename, CV_LOAD_IMAGE_GRAYSCALE);

		if( !faceImgArr[iFace] )
		{
			fprintf(stderr, "Can\'t load image from %s\n", imgFilename);
			return 0;
		}
	}

	fclose(imgListFile);

	return nFaces;
}



void printUsage()
{
	printf("Usage: eigenface <command>\n",
	       "  Valid commands are\n"
	       "    train\n"
	       "    test\n");
}


